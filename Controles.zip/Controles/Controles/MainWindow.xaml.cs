﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Cache;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Controles
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Eleve Eleve { get; set; }
        public MainWindow()
        {
            InitializeComponent();
          
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            Eleve= new Eleve
            {
                Age = Convert.ToInt32(this.Age.Value),
                Nom = Nom.Text,
                Prenom= Prenom.Text,
            };

            MonDataGrid.Items.Add(Eleve);
             
            Nom.Clear();
            Prenom.Clear();
        }
    }
  



}
