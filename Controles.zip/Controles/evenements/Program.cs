﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace evenements
{
    internal class Program
    {
         
        static void Main(string[] args)
        {
            TemperatureSensor temp= new TemperatureSensor();
            temp.OnTemperatureCritical += (o,e) => {
                Console.WriteLine((o as TemperatureSensor).Temperature);
            };
            for (int i = 0; i < 500; i++)
            {
                temp.Temperature++;
            }
            Console.ReadKey();
        }
    }

    public class TemperatureSensor
    {
        

        // Déclaration de l'événement basé sur le délégué
        public EventHandler OnTemperatureCritical;

        private int _temperature;

        public int Temperature
        {
            get { return _temperature; }
            set
            {
                _temperature = value;
                // Déclenchement de l'événement si la température dépasse un seuil critique
                if (_temperature > 50)
                {
                    // Vérification s'il y a des abonnés avant de déclencher l'événement
                    OnTemperatureCritical?.Invoke(this, EventArgs.Empty);
                }
            }
        }
    }
}
